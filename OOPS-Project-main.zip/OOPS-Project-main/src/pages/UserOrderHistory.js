import React from "react";
import UserBar from "../components/UserBar";

function UserOrderHistory() {
  return (
    <div>
      <UserBar />
      <h3>User Order History</h3>
    </div>
  );
}

export default UserOrderHistory;
