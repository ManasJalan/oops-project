import * as React from "react";
import "./App.css";
import AllRoutes from "./router/AllRoutes";

function App() {
  return (
    <div>
      <AllRoutes />
    </div>
  );
}

export default App;
