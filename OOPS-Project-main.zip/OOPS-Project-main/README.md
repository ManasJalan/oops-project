# Online SuperMarket

### Project Description
* Full Stack Application with add to cart, search and payment functionality
* Separate Authentication and CRUD functionality for Users, Vendors and Admins
* Front-end implemented with REACT JS, Bootstrap, HTML and CSS
* Back-end implemented with Java Springboot, MySQL

